export default {
	changeToken (state, token){
		state.token = token
	},
	changeUserId (state, user_id){
		state.user_id = user_id
	}
}
