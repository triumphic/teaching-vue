export default {
	token: '455445555',
	user_id:'66'
}
