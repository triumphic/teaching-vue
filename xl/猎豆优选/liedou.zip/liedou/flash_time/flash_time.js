var sex = 0;
var loadingFlag = false;
var pageNum = 1;
var maxPage = 1;
var start_time = 0;
var end_time = 0;
var meiriData = [];
var navListData = [];
var con = '已开抢';
$().ready(function () {
	$(window).scroll(function(){
		if($(window).scrollTop()>= $(document).height()-$(window).height() - 318){
		//到达底部加载数据
			if(loadingFlag){
				pageNum ++ ;
				flashSaleData(start_time,end_time,pageNum,con)
			}
		}
		if($(window).scrollTop()>400){
			$('.head_item_nav').css({
				"display": "block",
				"position":"fixed",
				"top":"46px"
			})
		}else{
			$('.head_item_nav').css({
				"display": "none",
				"position":"static"
			})
		}
	});
	navlistData();
	flashSale();
	ieFontColor();
})
//ie浏览器
function ieFontColor () {
	
	if(!!window.ActiveXObject || "ActiveXObject" in window){
  		$(".activity_title .activity_title_left span").css({"color":"#CC1C0E","background":"#ffffff"})
  		$(".Recommend .activity_title .activity_title_left span").css({"color":"#5A6CFF","background":"#ffffff"})
	}
}
//限时抢购
function flashSale () {
	var html = '';
	var nowTime = Date.parse(new Date()).toString().substr(0,10);
	var timeIndex = 0;
	activityTime.forEach(function (item, index) {
		if(nowTime < item.timeStamp){
			item.con = "即将开始"
		}else{
			item.con = "已开抢"
		}
		if(nowTime - item.timeStamp <= 151200 && nowTime - item.timeStamp > 0){
			timeIndex = index;
		}else if(nowTime > activityTime[0].timeStamp && nowTime < activityTime[1].timeStamp){
			timeIndex = 0;
		}
		html += "<li><div>" + item.time + "</div><span>" + item.con + "</span></li>"
	})
	if(activityTime[timeIndex+1] == undefined){
		start_time = activityTime[timeIndex].timeStamp;
		end_time = time_24;
	}else{
		start_time = activityTime[timeIndex].timeStamp;
		end_time = activityTime[timeIndex+1].timeStamp;
	}
	$(".flash_time ul").html(html);
	$(".flash_time ul li").eq(timeIndex).addClass('flash_time_active')
	flashSaleData(start_time,end_time,1,"已开抢")//首次渲染时候调取
	clickFlash()
}
//点击各时间段的限时抢购
function clickFlash () {
	$(".flash_time ul li").click(function () {
		pageNum = 1;
		meiriData = [];
		start_time = activityTime[$(this).index()].timeStamp;
		con = activityTime[$(this).index()].con;
		if($(this).index() == $(".flash_time ul li").length-1){
			end_time = activityTime[0].timeStamp;
		}else{
			end_time = activityTime[$(this).index()+1].timeStamp;
		}
		$(".flash_time ul li").eq($(this).index()).addClass('flash_time_active').siblings().removeClass('flash_time_active');
		flashSaleData(start_time,end_time,1,con)
	})
}
//限时抢购接口
function flashSaleData (start_time,end_time,page,content) {
	loadingFlag = false;
	 $.ajax({
		type:'post',
		url: api.BASEURL + api.flashTime,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		data:{
			start_time: start_time,
			end_time: end_time,
			platform: 1,
			page: page,
			page_size: 20
		},
		success: function (res) {
			if(res && res.errno == 0 && res.rst){
				var html = '';
				if(res.rst.data.list.length == 0 && meiriData.length == 0){
					if(page == 1){
						$(".flash_sale .commodity_list ul").html('');
					}
					$(".loading").html("没有更多了")
					return;
				}
				if(res.rst.data.list.length>0){
					pageNum ++ ;
					if(meiriData.length != 0){
						meiriData = meiriData.concat(res.rst.data.list);
						if(content == "已开抢"){
							html = flash_time(meiriData)
						}else if(content == '即将开始'){
							html = flash_time_noStart(meiriData)
						}
					}else{
						meiriData = res.rst.data.list;
						if(content == "已开抢"){
							html = flash_time(meiriData)
						}else if(content == '即将开始'){
							html = flash_time_noStart(meiriData)
						}
					}
					$(".flash_sale .commodity_list ul").html(html)
					loadingFlag = true;
					$(".loading").html("努力加载中...")
				}else{
					$(".loading").html("没有更多了")
				}
			}else{
				alert(res.err)
			}
		},
		fail: function (err) {
			console.log(err)
		}
	})
}
//导航栏目(商品分类)
function navlistData (){
	$.ajax({
		type:"get",
		url: api.BASEURL + api.navList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			if(res.errno == 0 && res.rst){
					if(res.rst.data){
						navListData = res.rst.data;
						var navListHtml = '';
						navListData.forEach(function (item,index) {
							navListHtml += `<li data-id=${item.id}><a href="../list/index.html?id=${item.id}&path=nav">${item.name}</a></li>`
						})
						
						$(".head_item_nav ul").html(navListHtml);
					}
				}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}

//导航栏目(商品分类)
function navlistData (){
	$.ajax({
		type:"get",
		url: api.BASEURL + api.navList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			if(res.errno == 0 && res.rst){
					if(res.rst.data){
						navListData = res.rst.data;
						var navListHtml = '';
						navListData.forEach(function (item,index) {
							navListHtml += `<li data-id=${item.id}><a href="../list/index.html?id=${item.id}&path=nav">${item.name}</a></li>`
						})
						
						$(".head_item_nav ul").html(navListHtml);
					}
				}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}