var h = '';//浏览器高度
var w = '';//浏览器宽度
$().ready(function () {
	h = document.documentElement.clientHeight || document.body.clientHeight;
	w = document.documentElement.clientWidth || document.body.clientWidth;
})

//function srcoll () {
//	//鼠标滚珠上下滑动
//	var topx = 0
//	var status = 0;
//	var flagBotton = true;
//	var flagTop = null;
//	var numTop = 0;
//	var num = 0;
//	var numBottom = 0;
//	$(window).bind('mousewheel DOMMouseScroll', function(event) {
//		var pageArr = Array.prototype.slice.call($(".page"));
//		pageArr.forEach(function (item,index) {
//			if($(item).offset().top == 0){
//				status = $(item).attr("data-num")
//			}
//		})
//	//	console.log(status)
//		var winHeight = $(window).height();
//		if(numBottom != status && num = 0){
//			flagBotton = false;
//		}else{
//			flagBotton = true;
//		}
//		if (event.originalEvent.wheelDelta > 0 || event.originalEvent.detail < 0) {//向上滑动
//			numTop++;
//			if(numTop == 1){
//				flagTop = true;
//			}else{
//				flagTop = false;
//			}
//	//		console.log("向上")
//	//	    if (num > 0 && status == 0) {
//	//	        status = 1;
//	//	        topx = -(num - 1) * winHeight;
//	//	        obj.css('top', topx + "px");
//	//	        $('#zhuangt li').find('span').removeClass('select');
//	//	        $('#zhuangt li').eq(num - 1).find('span').addClass('select');
//	//	        
//	//	        setTimeout(function() {
//	//	            status = 0;
//	//	            obj.attr('data-num', num - 1);
//	//	            if (num === 4) {
//	//	                $('.nextbtn').find('i').attr('class', 'fa fa-angle-down');
//	//	            };
//	//	        }, 800);
//	//	    };
//	//		if(flagTop && status > 0 && status < 2){
//	//			setTimeout(function() {
//	//	        	pageArr.forEach(function (item, index) {
//	//	        		$(item).animate({
//	//	        		  "top":winHeight
//	//	        		});
//	//	        	})
//	//	        	flagTop=true;
//	//	        	console.log(status)
//	//	        }, 800);
//	//		}
//		} else {
//	//		console.log("向下")
//			num++;
//			if(num = 0){
//				
//			}
//			if(!flagBotton){
//				flagBotton = false;
//			}
//		    if (flagBotton && status < 2) {
//		        setTimeout(function() {
//		        	pageArr.forEach(function (item, index) {
//		        		$(item).animate({
//		        		  "top":-winHeight
//		        		});
//		        	})
//		        	flagBotton=true
//		        	console.log(status)
//		        }, 800);
//		    }
//		}
//	});
//}
