
function getTime (time){
	var date = new Date();
	date.setHours(time);
	date.setMinutes(time);
	date.setSeconds(time);
	date.setMilliseconds(time);
	return Date.parse(date).toString().substr(0,10)
}
//function getTimeTwo (time){
//	var date = new Date();
//	date.setHours(time);
//	date.setMinutes(time);
//	date.setSeconds(time);
//	date.setMilliseconds(time);
////	return date.getTime()
//	return Date.parse(date).toString().substr(0,10)
//}
//var now = new Date(parseInt(1530720000) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
//console.log(Number(getTime(0))+22*3600-Number(getTime(0))+20*3600)
var activityTime = [
	{
		"time": "00 : 00",
		"timeStamp": Number(getTime(0))
	},
	{
		"time": "08 : 00",
		"timeStamp": Number(getTime(0))+8*3600
	},
	{
		"time": "10 : 00",
		"timeStamp": Number(getTime(0))+10*3600
	},
	{
		"time": "12 : 00",
		"timeStamp": Number(getTime(0))+12*3600
	},
	{
		"time": "14 : 00",
		"timeStamp": Number(getTime(0))+14*3600
	},
	{
		"time": "16 : 00",
		"timeStamp": Number(getTime(0))+16*3600
	},
	{
		"time": "18 : 00",
		"timeStamp": Number(getTime(0))+18*3600
	},
	{
		"time": "20 : 00",
		"timeStamp": Number(getTime(0))+20*3600
	},
	{
		"time": "22 : 00",
		"timeStamp": Number(getTime(0))+22*3600
	}
];

var time_24 = Number(getTime(0))+24*3600
