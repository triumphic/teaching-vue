var sex = '';
var bannerData = [];
var pageNum = 1;
var maxPage = 1;
var loadingFlag = false;
var meiriData = [];//每日精选
var asideData = [];//banner左侧列表栏
var navListData = [];
var category_id = 13;
//点击刷新页面
function reload(){
	window.location.href = "../home/index.html";
	$(window).scrollTop(0);
}
//向下滑动  导航栏固定
$().ready(function () {
	
	$(window).scroll(function(){
		if($(window).scrollTop()>400){
			$('.head_item_nav').css({
				"display": "block",
				"position":"fixed",
				"top":"46px"
			})
		}else{
			$('.head_item_nav').css('display','none')		
		}
		
		if($(window).scrollTop()>= $(document).height()-$(window).height() - 318){
			//到达底部加载数据
			if(loadingFlag){
				pageNum ++ ;
				selected(pageNum,category_id); 
			}
		}
	});
	
	initData();
	navlistData();
	ieFontColor();
})


function initData () {
	flashSale();//限时抢购
	gatBannerData();
	asideListData();
	initHtml();
	selected(pageNum,category_id);
}

//ie浏览器
function ieFontColor () {
	
	if(!!window.ActiveXObject || "ActiveXObject" in window){
  		$(".container .homeList .homeListRight .advertisement ul li .img_right div:nth-of-type(2) span").css({"color":"#FF0000","background":"#ffffff"})
  		$(".container .homeList .homeListRight .advertisement ul li .img_right div:nth-of-type(2) span").find("em").css({"background":"#ffffff"})
  		$(".container .homeList .homeListRight .advertisement ul li:nth-of-type(2) .img_right div:nth-of-type(2) span").css({"color":"#CC00FF","background":"#ffffff"})
  		$(".activity_title .activity_title_left span").css({"color":"#CC1C0E","background":"#ffffff"})
  		$(".Recommend .activity_title .activity_title_left span").css({"color":"#5A6CFF","background":"#ffffff"})
	}
}
function initHtml () {
	sex = 0;
	$(".flash_sale .activity_title .activity_title_left i").css({
			'background':'url(https://kx-youhuiquan.oss-cn-beijing.aliyuncs.com/lieodu_gw/xianshiqianggou.png) no-repeat',
			'background-size':'100%'
			})
}

//轮播操作
function swiperEvent () {
	 var mySwiper = new Swiper ('.swiper-container', {
	    loop: false,
	   	centeredSlides: true,
	   	autoplay: {
	   		delay: 3000,
	   		disableOnInteraction: false//用户操作后还会自动轮播
	   	},
	    
	    // 如果需要分页器
	    pagination: {
	      el: '.swiper-pagination',
	      clickable: true//点击小点生效
	    },
	    
	    // 如果需要前进后退按钮
	    navigation: {
	      nextEl: '.swiper-button-next',
	      prevEl: '.swiper-button-prev',
	    },
	  }) 
}
//点击轮播图跳转
function goBanner () {
	$(".swiper-slide").click(function () {
		var url = $(this).attr("data-url");
		var name = $(this).attr("data-name");
		var group_id = $(this).attr("data-id")
		if(url){
			window.open(url); 
		}else{
			var id = $(this).attr("data-ids");
			window.location.href="../list/index.html?id=" + group_id + "&path=nav"
		}
	})
}
//获取轮播图数据
function gatBannerData () {
	$.ajax({
		type:"get",
		url: api.BASEURL + api.bannerList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			console.log(res)
			if(res.errno == 0 && res.rst){
				if(res.rst.data){
					bannerData = res.rst.data;
					var swiperHtml = '';
					bannerData.forEach(function (item,index) {
						swiperHtml += `<div class="swiper-slide" data-url="${item.url}" data-name="${item.note}" data-id="${item.group_id}" data-ids="${item.id}" >
								        	<img width="100%" src="${item.photo}" />
								        </div>`
					})
					$(".homeListRight .swiper-wrapper").html(swiperHtml);
				}
				swiperEvent();
				goBanner();
			}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}

//轮播图左边列表
function asideListData(){
	 $.ajax({
		type:'get',
		url: api.BASEURL + api.asideList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			console.log(res)
			var html = '';
			if(res.errno == 0 && res.rst){
				if(res.rst.data){
					asideData = res.rst.data;
					for(var i = 0 ; i<res.rst.data.length; i++) {
						html += "<li data-id=" + res.rst.data[i].id + "><i style='background:url(" +res.rst.data[i].img+ ") no-repeat;background-size: 100%;'" + "></i><span>" + res.rst.data[i].name + "</span></li>"
					}
					$(".homeList aside ul").html(html)
//					var iconLiList = Array.prototype.slice.call($(".homeList aside ul li"));
//					for(var i = 0; i<iconList.length; i++){
//						$(iconLiList[i]).find("i").css("background","url(" + iconList[i].icon + ")")
//					}
					asideHover();
				}
			}else{
				alert(res.err)
			}
		},
		fail: function (err) {
			console.log(err)
		}
	})
}
//左边列表栏划过效果
function asideHover () {
	$(".homeList aside ul li").hover(function () {
//		iconList.forEach(function (item, index) {
//			$(".homeList aside ul li").eq(index).find("i").css("background","url(" + iconList[index].icon + ")")
//		})
//		$(this).find("i").css("background","url(" + iconList[$(this).index()].icon_on + ")")
		if(!!window.ActiveXObject || "ActiveXObject" in window){
      		$(".homeList aside ul li span").css("color","#5B4242")
   			$(this).find("span").css('color','#CC1C0E');
   		}else{
   			$(".homeList aside ul li span").removeClass('asideHoverActive')
   			$(this).find("span").addClass('asideHoverActive');
   		}
	},function(){
		$(".homeList aside ul li span").removeClass('asideHoverActive')
	})
	//点击效果
	$(".homeList aside ul li").click(function () {
		var navListHtml = '';
		localStorage.setItem("navList",JSON.stringify(asideData[$(this).index()].itemList))
		window.location.href="../list/index.html?id=" + asideData[$(this).index()].itemList[0].id
	})
}
//每日精选
function selected (pageNum,category_id) {
	loadingFlag = false;
	if(maxPage < pageNum){
		$(".loading").html("没有更多了")
		return;
	}
	 $.ajax({
		type:'post',
		url: api.BASEURL + api.stocklistByCategoryId,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		data:{
			category_id:category_id,
			page:pageNum
		},
		success: function (res) {
			if(res && res.errno == 0 && res.rst){
				var html = '';
				maxPage = res.rst.pageInfo.maxPage;
				if(res.rst.data.length>0){
					if(meiriData.length != 0){
						meiriData = meiriData.concat(res.rst.data);
						html = template_home(meiriData)
//						console.log(meiriData)
					}else{
						meiriData = res.rst.data;
						html = template_home(meiriData)
					}
					$(".Recommend .commodity_list ul").html(html)
					loadingFlag = true;
					$(".loading").html("努力加载中...")
				}else{
					alert('暂无数据')
				}
			}else{
				alert(res.err)
			}
			
		},
		fail: function (err) {
			console.log(err)
		}
	})
}


//限时抢购
function flashSale () {
	var html = '';
	var nowTime = Date.parse(new Date()).toString().substr(0,10);
	var timeIndex = 0;
	var start_time = 0;
	var end_time = 0;
	activityTime.forEach(function (item, index) {
		if(nowTime - item.timeStamp <= 151200 && nowTime - item.timeStamp > 0){
			timeIndex = index;
		}else if(nowTime > activityTime[0].timeStamp && nowTime < activityTime[1].timeStamp){
			timeIndex = 0;
		}
	})
//	var times = activityTime[timeIndex+1].timeStamp - nowTime.toString().substr(0,10);
	if(activityTime[timeIndex+1] == undefined){
		var times = time_24 - Date.parse(new Date()).toString().substr(0,10)
	}else{
		var times =activityTime[timeIndex+1].timeStamp - Date.parse(new Date()).toString().substr(0,10)
	}
	console.log(activityTime[timeIndex+1].timeStamp + "one")
	console.log(Date.parse(new Date()).toString().substr(0,10))
	console.log(times)
	count_down(times)
	flashSaleData(activityTime[timeIndex].timeStamp,activityTime[timeIndex+1].timeStamp,1)//首次渲染时候调取
}

//限时抢购接口
function flashSaleData (start_time,end_time,page) {
//	http://yhq.quyaqu.com/api/v2/goods/taoQiangGouDataList
	 $.ajax({
		type:'post',
		url: api.BASEURL + api.advFourList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		data:{
			start_time: start_time,
			end_time: end_time,
			platform: 1,
			page: page,
			page_size: 20
		},
		success: function (res) {
			var html = '';
			if(res && res.errno && res.rst){
				var quan = '';
				res.rst.list[0].dataList.forEach(function (item, index) {
					var id=item.goods_id;
					var is_coupon=item.is_coupon;
					var coupon_price=item.coupon_price;
					var price=item.price;
					var discount_price=item.discount_price;
					var commission_rate=item.commission_rate;
					if(index < 4){
						if(item.coupon_id){
							quan = "<div class=commodity_quan><span>券</span><span>" + item.coupon_price + "元</span></div>"
						}
						html += "<li><a href='../details/index.html?goods_id="+id+"&is_coupon="+is_coupon+"&coupon_price="+coupon_price+"&price="+price+"&discount_price="+discount_price+"&commission_rate="+commission_rate+"' class='lp_li_a'><img src=" + item.img + " /><div class=commodity><div class=commodity_name>" + item.title + "</div><div class=commodity_introduce>" + quan + "<div class=commodity_number>付款人数：<span>" + item.sale_num + "</span></div></div><div class=commodity_price><div><span class=nowPrice>￥" + item.discount_price + "</span><span class=oldPrice>￥" + item.price + "</span></div><div>立即抢购</div></div><div class=commodity_jdt><div class=progress><div class=progress_value  style=width:" + item.sale_num/item.total_num*100 + "%></div><span>剩余" + Number(item.total_num-item.sale_num) + "件</span></div></div></div></a></li>"
					}
				})
				$(".flash_sale .commodity_list ul").html(html)
			}
		},
		fail: function (err) {
			console.log(err)
		}
	})
}
//倒计时
function count_down (times) {
	var timer=null;
	timer=setInterval(function(){
	    var day=0,
	      hour=0,
	      minute=0,
	      second=0;//时间默认值
	    if(times > 0){
	      day = Math.floor(times / (60 * 60 * 24));
	      hour = Math.floor(times / (60 * 60)) - (day * 24);
	      minute = Math.floor(times / 60) - (day * 24 * 60) - (hour * 60);
	      second = Math.floor(times) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
	      if (day <= 9) day = '0' + day;
	      if (hour <= 9) hour = '0' + hour;
	      if (minute <= 9) minute = '0' + minute;
	      if (second <= 9) second = '0' + second;
	      $(".time_count_down").html(hour + "&ensp;:&ensp;" + minute + "&ensp;:&ensp;" + second)
	    }
//	    console.log(day+"天:"+hour+"小时："+minute+"分钟："+second+"秒");
	    if(times<=0){
	        clearInterval(timer);
	        flashSale();
	    }
	    times--;
	},1000);
}
//导航栏目(商品分类)
function navlistData(){
	$.ajax({
		type:"get",
		url: api.BASEURL + api.navList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success:function(res) {
			if(res.errno == 0 && res.rst){
					if(res.rst.data){
						navListData = res.rst.data;
						var navListHtml = '';
						navListData.forEach(function (item,index) {
							navListHtml += `<li data-id=${item.id}><a href="../list/index.html?id=${item.id}&path=nav">${item.name}</a></li>`
						})
						$(".head_item_nav ul").html(navListHtml);
					}
				}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}