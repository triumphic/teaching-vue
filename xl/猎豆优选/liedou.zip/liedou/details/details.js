var navListData = [];
var detailsData = [];
var token = '';
var id = 0;//产品id
var is_coupon = 0;//是否有优惠券
var err = '';
//向下滑动  导航栏固定
$().ready(function () {
	if(!!window.ActiveXObject || "ActiveXObject" in window){
  		$(".recommend_tit_style .rec").css({"color":"#5A6CFF","background":"#ffffff"})
  		$(".com_deta").css({"color":"#FF374A","background":"#ffffff"})
	}
	$(window).scroll(function(){
		if($(window).scrollTop()>400){
			$('.head_item_nav').css({
//				"display": "block",
				"position":"fixed",
				"top":"46px"
			})
		}else{
			$('.head_item_nav').css({
//				"display": "block",
				"position":"static"
			})
		}
	});
	navlistData();
	$('.head_item_nav').css('display','block')
})
$().ready(function(){
  //获取url中的参数
  function getUrlParam(name) {
   var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
   var r = window.location.search.substr(1).match(reg); //匹配目标参数
   if (r != null) return unescape(r[2]); return null; //返回参数值
  }
  //接收URL中的参数
   	  id = getUrlParam('goods_id');
      is_coupon=getUrlParam('is_coupon');
  var coupon_price=getUrlParam('coupon_price');
  var price=getUrlParam('price');
  var discount_price=getUrlParam('discount_price');
  var commission_rate=getUrlParam('commission_rate');
  //请求详情页数据
  	$.ajax({
	  	type:'post',
		url: api.BASEURL + api.details_two,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		data:{
			goods_id:id,  //产品id
			is_coupon:is_coupon, //1：有优惠券，0：没有优惠券
			coupon_price:coupon_price, //券价格
			price:price,  //价格
			discount_price:discount_price, //折扣价
			commission_rate:commission_rate //佣金比率
		},
		success:function(res,status){
			if(res.errno == 0 && res.rst){
				if(res.rst.data){
					detailsData = res.rst.data;
					var dateailsHtml = '';
					var detailsImgHtml='';
						var shop = "";
						if(!(res.rst.data.shop)){
							shop = '';
						}else{
							shop = `<div class="line_one"></div>
								<div class="com_shopname">
									<img src="${detailsData.shop.pic_path}" alt="" />
									<div class="com_shopname_head">
										<span class="com_shopname_tit">${detailsData.shop.title}</span>
									</div>
									<div class="com_shopname_grade">
										<span>宝贝描述：${detailsData.shop.item_score}</span>
										<span>商家服务：${detailsData.shop.service_score}</span>
										<span>物流服务：${detailsData.shop.delivery_score}</span>
									</div>
								</div>`;
						}
						var quan= '';
						var buttonDiv = '';
						if(detailsData.coupon_price !== "0"){
							quan =`<div class="com_quan"><span>券</span><span>${detailsData.coupon_price}元</span></div>`
							buttonDiv = '去领券'
						}else{
							buttonDiv = '立即抢购'
						}
						dateailsHtml += `<div class="com_img"><img src="${detailsData.small_img[0]}" alt="商品图片" /></div>
							<div class="com_con">
								<div class="com_tit">${detailsData.title}</div>
								<div class="com_cen">
									${quan}
									<div class="com_number">付款人数：${detailsData.volume}</div>
								</div>
								<div class="com_now_price"><span>劵后价：</span><span>¥${detailsData.discount_price}</span></div>
								<div class="com_old_price">原价：¥${detailsData.price}</div>
								<div class="com_getCoupon"><a href="javascript:void(0)">${buttonDiv}</a></div>
							</div>${shop}`;
					//商品详情图片  
					detailsImgHtml +=`<div class="outer-container">
    					<iframe  marginWidth=0 marginHeight=0 src="${detailsData.detail_url}"  scrolling="auto" frameBorder=0 width="102%" height="8020"></iframe>
					</div>`
					$(".details_com").html(dateailsHtml);
					$(".com_details_img").html(detailsImgHtml);
					//meta搜索keyword
					$("[name|='keywords']").attr("content",detailsData.title + "--猎豆优选")
					$("[name|='description']").attr("content",detailsData.title + "--猎豆优选")
					getToken();
				}
			}
		},
		fail:function(err){
			console.log(err)
		}
  	})
  
  	//相关推荐
	$.ajax({
		type:'post',
		url: api.BASEURL + api.correlation,
		data:{
			goods_id:id,
			count:4
		},
		dataType:"json",
		headers:{
			sex:api.sex,
			source:api.source
		},
		success:function(res){
			var json=res;
			var data=json.results.n_tbk_item;
			var corHtml = '';
			data.forEach(function (item, index) {
				var id=item.num_iid;
//				var is_coupon=item.is_coupon;
				var price=item.reserve_price; //商品原价
				var discount_price=item.zk_final_price; //商品折后价
				var a = price -  discount_price;  //券价格
				var coupon_price= parseInt(a);
//				var commission_rate=item.commission_rate;
              //<a href='/liedou/details/index.html?goods_id="+id+"&is_coupon="+is_coupon+"&coupon_price="+coupon_price+"&price="+price+"&discount_price="+discount_price+"&commission_rate="+commission_rate+"' class='lp_li_a'></a>
				var quan = '';
				if(coupon_price){
					quan = "<div class=commodity_quan><span>券</span><span>"+coupon_price+"元</span></div>"
				}     
				var img= item.pict_url;
				corHtml += "<li><a href='../details/index.html?goods_id="+id+"&coupon_price="+coupon_price+"&price="+price+"&discount_price="+discount_price+"' class='lp_li_a'><img src=" + img + " /><div class=commodity><div class=commodity_name>" + item.title + "</div><div class=commodity_introduce>"+ quan +"</div><div class=commodity_price><div><span class=nowPrice>￥" + item.zk_final_price + "</span><span class=rem_oldPrice>原价:<i>￥" + item.reserve_price + "</i></span></div></div></div></a></li>";

//				goTaoBao(item)
			})
			$(".commodity_list ul").html(corHtml);
				
		},
		fail:function(err){
			console.log(err)
		}
	})
//	function goTaoBao(item){
//		console.log(item)
//		window.location.href=item.item_url;
//	}


})

//导航栏目(商品分类)
function navlistData (){
	$.ajax({
		type:"get",
		url: api.BASEURL + api.navList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			if(res.errno == 0 && res.rst){
					if(res.rst.data){
						navListData = res.rst.data;
						var navListHtml = '';
						navListData.forEach(function (item,index) {
							navListHtml += `<li data-id=${item.id}><a href="../list/index.html?id=${item.id}&path=nav">${item.name}</a></li>`
						})
						
						$(".head_item_nav ul").html(navListHtml);
					}
				}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}
//点击去领券
function goVoucher () {
	if($(".com_getCoupon").find("a").attr("href") == "javascript:void(0)"){
		$(".com_getCoupon").click(function () {
			alert(err)
		})
	}
}

//获取token
function getToken () {
	$.ajax({
		type:"get",
		url: api.BASEURL + api.getToken,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			if(res.errno == 0 && res.rst){
				token = res.rst.token;
				orderDownData()
			}else{
				err=res.err;
			}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}

//用户下订单
function orderDownData () {
	$.ajax({
		type:"post",
		url: api.BASEURL + api.orderDown,
		headers:{
			sex:api.sex,
			source:api.source,
			token:token
		},
		dataType:"json",
		data:{
			goods_id:id,
			is_coupon:is_coupon
		},
		success: function (res) {
			if(res.errno == 0 && res.rst){
				$(".com_getCoupon").find("a").attr("href",res.rst.url)
			}else{
				err = res.err;
				goVoucher();
			}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}
