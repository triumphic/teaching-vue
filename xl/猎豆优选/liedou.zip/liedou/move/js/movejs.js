var flag = false;
swiperPage();
function swiperPage () {
	var mySwiper = new Swiper(".swiper-container", {
      direction: "vertical", //纵向展示
//			      pagination: ".swiper-pagination", //小点
      //virtualTranslate : true,
      mousewheelControl: true,
      onInit: function(swiper) {
        swiperAnimateCache(swiper);
        swiperAnimate(swiper);
      },
      onSlideChangeEnd: function(swiper) {
        swiperAnimate(swiper);
      },
      onTransitionEnd: function(swiper) {
        swiperAnimate(swiper);
      },
      watchSlidesProgress: true,
      onProgress: function(swiper) {
        for (var i = 0; i < swiper.slides.length; i++) {
          var slide = swiper.slides[i];
          var progress = slide.progress;
          var translate = progress * swiper.height / 4;
          var scale = 1 - Math.min(Math.abs(progress * 0.5), 1);
          var opacity = 1 - Math.min(Math.abs(progress / 2), 0.5);
          slide.style.opacity = opacity;
          var es = slide.style;
          es.webkitTransform = es.MsTransform = es.msTransform = es.MozTransform = es.OTransform = es.transform =
            "translate3d(0," +
            translate +
            "px,-" +
            translate +
            "px) scaleY(" +
            scale +
            ")";
        }
      },
      onSetTransition: function(swiper, speed) {
        for (var i = 0; i < swiper.slides.length; i++) {
          var es = swiper.slides[i].style;
          es.webkitTransitionDuration = es.MsTransitionDuration = es.msTransitionDuration = es.MozTransitionDuration = es.OTransitionDuration = es.transitionDuration =
            speed + "ms";
        }
      }
	});    
}
function downloadApp () {
	if(navigator.userAgent.match(/(iPhone|iPod|iPad);?/i)){
		window.location.href='https://itunes.apple.com/cn/app/id1391124408?mt=8';
	}
	if(navigator.userAgent.match(/android/i)){
		if(navigator.userAgent.toLowerCase().match(/MicroMessenger/i) == "micromessenger"){
			//微信
			showMsg()
		}else if (navigator.userAgent.toLowerCase().match(/WeiBo/i) == "weibo"){
			//新浪微博
			showMsg()
		}else if (navigator.userAgent.toLowerCase().match(/QQ/i) == "qq"){
			//qq空间
			showMsg()
		}else{
			window.location.href='http://apitbk.726p.com/liedou_android.apk';
		}
	}
}
function showMsg() {
	flag = true;
    setTimeout(function() {
        flag = false
    }, 3000);
}

var alertInfo = document.getElementsByClassName("alert-info")[0];
if(flag){
	alertInfo.style.display = "block";
}else{
	alertInfo.style.display = "none";
}
