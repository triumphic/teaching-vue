/**
 * given an url with query parameters, this function returns all the 
 * query parameters as an object with name and value as key and value respectively.
 */
function parseQueryString(url) {
    var urlObj = {};
    var reg = /([^?=&]+)=([^?=&]+)/g;
    url.replace(reg, ($0, $1, $2) => {
        urlObj[$1] = decodeURIComponent($2);
    })
    return urlObj;
}