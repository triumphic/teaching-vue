$("#item-list-footer").load("../common/common-html/common-html.html #footer");
$("#item-list-evm").load("../common/common-html/common-html.html #liedou_ewm",function () {
	goTop();
});
var hintData = [];
$("#item-list-head").load("../common/common-html/common-html.html #head",function () {
	var iptName ='';
	var num = -1;
	var sex = sex;
	$("#head_input").keyup(function(event){
		console.log(event.keyCode)
	　　if(event.keyCode == 13){
			hiddenHint();
			window.location.href = "../search/index.html?searchName=" + $("#head_input").val() + "&path=nav"
		}
		if($("#head_input").val()){
			iptName = $("#head_input").val();
		}
		
	//	搜索框提示
		$.ajax({
			type:"get",
			url: api.BASEURL + api.hint,
			data:{
				name:$('#head_input').val()
			},
			dataType:"json",
			headers:{
				sex:api.sex,
				source:api.source
			},
			success: function (res) {
				//console.log(res.rst.data)
				if(res.errno == 0 && res.rst){
					if(res.rst.data){
						hintData = res.rst.data;
						var hintHtml = '';
						hintData.forEach(function (item,index) {
							hintHtml += `<p class="head_input_hint_item">${item}</p >`
						})
						if(hintHtml !== ''){
							hintHtml = hintHtml + `<p class="head_input_hint_close" id='close'>关闭</p >`
						}
						$(".head_input_hint").html(hintHtml);
						$(".head_input_hint_close").css('visibility','visible')
					}	
				}	
			},
			fail: function (err) {
				console.log(err)
			}
		});
	});
	
	
	$(window).scroll(function(){
		if($(window).scrollTop()>400){
			$(".head_bottom_warp").css({
				"position": "fixed",
    			"top": 0
			})
			$('.head_nav_search').css('display','block')
			$('.head_input_hint_mini').css('display','block')
				$(".head_input_hint_close").css('visibility','hidden')
		}else{
			$(".head_bottom_warp").css({
				"position": "static"
			})
			$('.head_nav_search').css('display','none')
			$('.head_nav_search').val('')
			$('.head_input_hint_mini').css('display','none')	
			$(".head_input_hint_close").css('visibility','visible')
			
		}
		if($(window).scrollTop()>2500){
			$(".scrollShow").css("display","block");
			$("#liedou_ewm").css({
				"height":"280px",
				"background":"url(../common/common-images/liedou_evm_two.png) no-repeat"
			})
		}else{
			$(".scrollShow").css("display","none");
			$("#liedou_ewm").css({
				"height":"210px",
				"background":"url(../common/common-images/liedou_ewm.png) no-repeat"
			})
		}
		
	});
	
	//  获取焦点时 文字颜色变化
	$("#head_input").focus(function(){
		$(".head_input_hint").css('visibility','visible')
		$(".head_input_hint_close").css('visibility','visible')
		$("#head_input").css('color','#333333');
	})
	$("#head_input_mini").focus(function(){
		$(".head_input_hint_mini").css('visibility','visible')
		$(".head_input_hint_close_mini").css('visibility','visible')
		$("#head_input_mini").css('color','#333333');
	})
	//  失去焦点时 文字颜色变化
	$("#head_input").blur(function(){
		$("#head_input").css('color','#bfbfbf');	
		$(".head_input_hint_close").css('visibility','hidden')
		
	})
	$("#head_input_mini").blur(function(){
		$("#head_input_mini").css('color','#bfbfbf');		
	})
	
	//  选择搜索框内的内容
	$('.head_input_hint').click(function(e){
		var target = e.target;
		var itemNews = $(e.target).text()
		if(itemNews != '关闭'){
			$('#head_input').val(itemNews)
			window.location.href = "../search/index.html?searchName=" + $("#head_input").val() + "&path=nav"
		}
		hiddenHint();
	})
	$("#head_btn").click(function () {
		window.location.href = "../search/index.html?searchName=" + $("#head_input").val() + "&path=nav"
	})
	

	//小搜索框
	var iptName_two = '';
	$("#head_input_mini").keyup(function(event){
//		console.log(event.keyCode)
	　　if(event.keyCode == 13){
			hiddenHint();
			window.location.href = "../search/index.html?searchName=" + $("#head_input_mini").val() + "&path=nav"
		}
		if($("#head_input_mini").val()){
			iptName_two = $("#head_input_mini").val();
		}
			//	搜索框提示
		$.ajax({
			type:"get",
			url: api.BASEURL + api.hint,
			dataType:"json",
			data:{
				name:$('#head_input_mini').val()
			},
			headers:{
				sex:api.sex,
				source:api.source
			},
			success: function (res) {
				//console.log(res.rst.data)
				if(res.errno == 0 && res.rst){
					if(res.rst.data){
						hintData = res.rst.data;
						var miniHtml = '';
						hintData.forEach(function (item,index) {
							miniHtml += `<p class="head_input_hint_item_mini">${item}</p >`
						})
						if(miniHtml !== ''){
							miniHtml = miniHtml + `<p class="head_input_hint_close_mini" id='close'>关闭</p >`
						}
						$(".head_input_hint_mini").html(miniHtml);
						$(".head_input_hint_close").css('visibility','visible')
						$(".head_input_hint_mini").val('');
					}	
				}
				
			},
			fail: function (err) {
				console.log(err)
			}
		});
	})
	//  选择小搜索框内的内容
	$('.head_input_hint_mini').click(function(e){
		var target = e.target;
		var itemNews = $(e.target).text()
		if(itemNews != '关闭'){
			$('#head_input_mini').val(itemNews)
			window.location.href = "../search/index.html?searchName=" + $("#head_input_mini").val() + "&path=nav"
		}
		hiddenHint();
	})

	$(".head_top_con_search").click(function () {
		return false
	})
	$("body").click(function () {
		$("#head_input_hint").css('visibility','hidden')
	})

	//点击刷新页面
	$(".head_top_con_logo_img").click(function () {
		window.location.href = "../home/index.html";
		$(window).scrollTop(0);
	})
	$(".head_shop").click(function () {
		window.location.href = "../home/index.html";
		$(window).scrollTop(0);
	})
	
	//点击跳转其他页面
	var pageArr = Array.prototype.slice.call($(".head_nav ul li"));
		pageArr.forEach(function (item,index) {
			var str=location.href;  //取得整个地址栏
			if(str.indexOf("makeMoney") != -1){
				$(".head_bottom_con .head_shop").removeClass("pageActive")
				$(".head_nav ul li").eq(0).addClass("pageActive")
			}else if(str.indexOf("enlist") != -1){
				$(".head_bottom_con .head_shop").removeClass("pageActive")
				$(".head_nav ul li").eq(1).addClass("pageActive")
			}else if(str.indexOf("about") != -1){
				$(".head_bottom_con .head_shop").removeClass("pageActive")
				$(".head_nav ul li").eq(2).addClass("pageActive")
			}else if(str.indexOf("phone") != -1){
				$(".head_bottom_con .head_shop").removeClass("pageActive")
				$(".head_nav ul li").eq(3).addClass("pageActive")
			}else{
				$(".head_bottom_con .head_shop").addClass("pageActive")
			}
		})
	
});


//隐藏搜索框提示
function hiddenHint(){
	$(".head_input_hint").css('visibility','hidden')
	$(".head_input_hint_close").css('visibility','hidden')
	$(".head_input_hint_mini").css('visibility','hidden')
	$(".head_input_hint_close_mini").css('visibility','hidden')

	$(".head_input_hint_close").click(function () {
		$(".head_input_hint").css('visibility','hidden')
		$(".head_input_hint_close").css('visibility','hidden')
	})
}



//回到顶部及划过效果
function goTop () {
	$("#liedou_ewm .evm").hover(function () {
		$("#liedou_ewm .bigEvm").css("display","block")
    },function () {
		$("#liedou_ewm .bigEvm").css("display","none")
    })
	$(".scrollShow img").click(function () {
		if ($('html').scrollTop()) {
            $('html').animate({ scrollTop: 0 }, 800);
            return false;
        }
        $('body').animate({ scrollTop: 0 }, 800);
	})
}


//点击刷新页面
function reload(){
	window.location.href = "../home/index.html";
	$(window).scrollTop(0);
}
if((navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i))) {
	//非pc
	window.location.href="../move/index.html";
}
