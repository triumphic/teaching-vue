var qs = parseQueryString(window.location.href);
var id = 0;
var sex = '';
var pageNum = 1;
var maxPage = 1;
var loadingFlag = false;
var meiriData = [];//每日精选
var nav_id = '';
var navListData = [];

$().ready(function () {
	init();
})
function parseQueryString(url) {
    var urlObj = {};
    var reg = /([^?=&]+)=([^?=&]+)/g;
    url.replace(reg, ($0, $1, $2) => {
        urlObj[$1] = decodeURIComponent($2);
    })
    return urlObj;
}
function init () {
	$(".head_item_nav").css("display","block")
	if(qs.path == "nav"){
		navlistData()
	}else{
		var navListHtml = "";
		if(localStorage.getItem("navList")){
			JSON.parse(localStorage.getItem("navList")).forEach(function (item,index) {
				navListHtml += `<li data-id="${item.id}"><a href="javascript:void(0)">${item.name}</a></li>`
			})
			$(".head_item_nav ul").html(navListHtml);
			$(".head_item_nav ul li").eq(0).find("a").addClass("navActive");
		}
	}
	if(qs.id){
		nav_id = qs.id;
	}
	selected(nav_id,1)
	scrollNav();
	clickNav();
}
//scroll
function scrollNav () {
	
	$(window).scroll(function(){
		if($(window).scrollTop()>= $(document).height()-$(window).height() - 318){
		//到达底部加载数据
			if(loadingFlag){
				pageNum ++ ;
				selected(nav_id,pageNum); 
			}
		}
		
		if($(window).scrollTop()>400){
			$('.head_item_nav').css({
				"display": "block",
				"position":"fixed",
				"top":"46px"
			})
		}else{
			$('.head_item_nav').css({
				"display": "block",
				"position":"static"
			})
		}
	});
	
}
//产品列表
function selected (nav_id,pageNum) {
	loadingFlag = false;
	if(maxPage < pageNum){
		$(".loading").html("没有更多了")
		return;
	}
	 $.ajax({
		type:'post',
		url: api.BASEURL + api.stocklistByCategoryId,
		headers:{
			sex:api.sex,
			source:api.source
		},
		data:{
			sort:1,
			category_id:nav_id,
			page:pageNum
		},
		dataType:"json",
		success: function (res) {
			if(res && res.errno == 0 && res.rst){
				var html = '';
				maxPage = res.rst.pageInfo.maxPage;
				if(res.rst.data.length>0){
					if(meiriData.length != 0){
						meiriData = meiriData.concat(res.rst.data);
						html = template_home(meiriData)
					}else{
						meiriData = res.rst.data;
						html = template_home(meiriData)
					}
					$(".Recommend .commodity_list ul").html(html)
					loadingFlag = true;
					$(".loading").html("努力加载中...")
				}else{
					if(pageNum == 1){
						$(".Recommend .commodity_list ul").html(html)
					}
					$(".loading").html("没有更多了")
				}
			}else{
				alert(res.err)
			}
			
		},
		fail: function (err) {
			console.log(err)
		}
	})
}
//点击navlist切换列表
function clickNav () {
	$(".head_item_nav ul li").click(function () {
		$(".head_item_nav ul li a").removeClass("navActive")
		$(this).find("a").addClass("navActive").siblings()
		meiriData = [];
		pageNum = 1;
		maxPage = 1;
		nav_id = $(this).attr("data-id");
		selected(nav_id,pageNum)
		if ($('html').scrollTop()) {
            $('html').animate({ scrollTop: 0 }, 1);
            return false;
        }
        $('body').animate({ scrollTop: 0 }, 1);
	})
}

//导航栏目(商品分类)
function navlistData (){
	$.ajax({
		type:"get",
		url: api.BASEURL + api.navList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			if(res.errno == 0 && res.rst){
				var idx = 0;
					if(res.rst.data){
						navListData = res.rst.data;
						var navListHtml = '';
						navListData.forEach(function (item,index) {
							navListHtml += `<li data-id=${item.id}><a href="javascript:void(0)">${item.name}</a></li>`;
							if(item.id == nav_id){
								idx = index;
							}
						})
						
						$(".head_item_nav ul").html(navListHtml);
						$(".head_item_nav ul li").eq(idx).find("a").addClass("navActive");
						clickNav()
					}
				}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}
