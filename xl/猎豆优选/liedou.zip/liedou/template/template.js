function template_home (data) {
	//每日推荐
	var html = '';
//	console.log(data)
	data.forEach(function (item, index) {
		var id=item.goods_id;
		var is_coupon=item.is_coupon;
		var coupon_price=item.coupon_price;
		var price=item.price;
		var discount_price=item.discount_price;
		var commission_rate=item.commission_rate;
		var quan = '';
		if(item.is_coupon){
			quan = "<div class=commodity_quan><span>券</span><span>" + item.coupon_price + "元</span></div>"
		}
		html += "<li><a href='../details/index.html?goods_id="+id+"&is_coupon="+is_coupon+"&coupon_price="+coupon_price+"&price="+price+"&discount_price="+discount_price+"&commission_rate="+commission_rate+"' target='_blank' class='lp_li_a'><img src=" + item.img + " /><div class=commodity><div class=commodity_name>" + item.title + "</div><div class=commodity_introduce>" + quan + "<div class=commodity_number>付款人数：<span>" + item.volume + "</span></div></div><div class=commodity_price><div><span class=nowPrice>￥" + item.discount_price + "</span><span class=oldPrice>￥" + item.price + "</span></div><div>立即抢购</div></div></div></a></li>";
		
})
	return html;
}


function flash_time (data) {
	//限时抢购
	var html = '';
	data.forEach(function (item, index) {
		var id=item.goods_id;
		var is_coupon=item.is_coupon;
		var coupon_price=item.coupon_price;
		var price=item.price;
		var discount_price=item.discount_price;
		var commission_rate=item.commission_rate;
		var quan = '';
		var ratio = item.sale_num/item.total_num*100;
		if(item.coupon_id){
			quan = "<div class=commodity_quan><span>券</span><span>" + item.coupon_price + "元</span></div>"
		}
		html += "<li><a href='../details/index.html?goods_id="+id+"&is_coupon="+is_coupon+"&coupon_price="+coupon_price+"&price="+price+"&discount_price="+discount_price+"&commission_rate="+commission_rate+"' target='_blank' class='lp_li_a'><img src=" + item.img + " /><div class=commodity><div class=commodity_name>" + item.title + "</div><div class=commodity_introduce>" + quan + "<div class=commodity_number>付款人数：<span>" + item.sale_num + "</span></div></div><div class=commodity_price><div><span class=nowPrice>￥" + item.discount_price + "</span><span class=oldPrice>￥" + item.price + "</span></div><div>立即抢购</div></div><div class=commodity_jdt><div class=progress><div class=progress_value  style=width:" + ratio + "%></div><span>剩余" + Number(item.total_num-item.sale_num) + "件</span></div></div></div></a></li>"
	})
	return html;
}

function flash_time_noStart (data) {
	//限时抢购
	var html = '';
	data.forEach(function (item, index) {
		var id=item.goods_id;
		var is_coupon=item.is_coupon;
		var coupon_price=item.coupon_price;
		var price=item.price;
		var discount_price=item.discount_price;
		var commission_rate=item.commission_rate;
		var quan = '';
		var ratio = item.sale_num/item.total_num*100;
		if(item.coupon_id){
			quan = "<div class=commodity_quan><span>券</span><span>" + item.coupon_price + "元</span></div>"
		}
		html += "<li><a href='javascript:void(0)' class='lp_li_a'><img src=" + item.img + " /><div class=commodity><div class=commodity_name>" + item.title + "</div><div class=commodity_introduce>" + quan + "<div class=commodity_number>付款人数：<span>" + item.sale_num + "</span></div></div><div class=commodity_price><div><span class=nowPrice>￥" + item.discount_price + "</span><span class=oldPrice>￥" + item.price + "</span></div><div style=background:#ccc>立即抢购</div></div><div class=commodity_jdt><div class=progress><div class=progress_value  style=width:" + ratio + "%></div><span>剩余" + Number(item.total_num-item.sale_num) + "件</span></div></div></div></a></li>"
	})
	return html;
}