var api = {
//	BASEURL : '',//解决跨域
	
//	BASEURL : 'https://tbk.726p.com/',
	BASEURL : 'http://www.liedou.com',
	
	//渠道号
	source : '3100',
	
	//性别
	sex : '0',
	
	//接口relativeURL
	//首页导航栏列表
	asideList : '/api/v2/category/list',
	//轮播图
	bannerList : '/api/v2/homeact/list',
	//省-钱-达-人---广告位
	groupNewGoldGroups : '/api/v2/channel/groupNewGoldGroups',
	
	//修改性别
	userSetSex : '/api/v2/users/userSetSex',
	
	//搜索列表
	search : '/api/v2/goods/search',
	
	//用户信息
	userinfo : '/api/v2/users/userInfo',
	
	//搜索提示
	hint : '/api/category/searchAdvice',
	
	//每日精选----及产品列表
	stocklistByCategoryId : '/api/v2/goods/stocklistByCategoryId',
	
	//导航栏目
	navList : '/api/v2/channel/list',
	
	//限时抢购列表
	flashTime : '/api/v2/goods/taoQiangGouDataList',
	
	//限时抢购top
	advFourList : '/api/v2/channel/advFourList',
	
	//详情页
	details_two : '/api/v2/goods/detail',
	
	//相关推荐
	correlation : '/api/v2/tbk/itemRecommand',
	
	//推荐列表
	correlationList: '/api/v2/goods/recommendtop',
	
	//token
	getToken: '/api/v2/users/getAuserToken',
	
	//用户下订单接口
	orderDown: '/api/v2/adzoneCreate/orderDown'
	
}
