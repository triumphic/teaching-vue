var qs = parseQueryString(window.location.href);
var id = 0;
var sex = 0;
var pageNum = 1;
var maxPage = 1;
var loadingFlag = false;
var meiriData = [];
var navListData = [];

$().ready(function () {
	init();
})
function parseQueryString(url) {
    var urlObj = {};
    var reg = /([^?=&]+)=([^?=&]+)/g;
    url.replace(reg, ($0, $1, $2) => {
        urlObj[$1] = decodeURIComponent($2);
    })
    return urlObj;
}
function init () {
	$(".head_item_nav").css("display","block")
	if(qs.path == "nav"){
		navlistData()
	}
	if(qs.searchName){
		searchData(qs.searchName,1)
	}
	scrollNav();
}
//scroll
function scrollNav () {
	
	$(window).scroll(function(){
		if($(window).scrollTop()>= $(document).height()-$(window).height() - 318){
		//到达底部加载数据
			if(loadingFlag){
				pageNum ++ ;
				searchData(qs.searchName,pageNum); 
			}
		}
		
		if($(window).scrollTop()>400){
			$('.head_item_nav').css({
				"display": "block",
				"position":"fixed",
				"top":"46px"
			})
		}else{
			$('.head_item_nav').css({
				"display": "block",
				"position":"static"
			})
		}
	});
	
}

//导航栏目(商品分类)
function navlistData (){
	$.ajax({
		type:"get",
		url: api.BASEURL + api.navList,
		headers:{
			sex:api.sex,
			source:api.source
		},
		dataType:"json",
		success: function (res) {
			if(res.errno == 0 && res.rst){
					if(res.rst.data){
						navListData = res.rst.data;
						var navListHtml = '';
						navListData.forEach(function (item,index) {
							navListHtml += `<li data-id=${item.id}><a href="../list/index.html?id=${item.id}&path=nav">${item.name}</a></li>`
						})
						
						$(".head_item_nav ul").html(navListHtml)
					}
				}
		},
		fail: function (err) {
			console.log(err)
		}
	});
}

//搜索列表
function searchData(name,pageNum) {
	loadingFlag = false;
	if(maxPage < pageNum){
		$(".loading").html("没有更多了")
		return;
	}
	 $.ajax({
		type:'post',
		url: api.BASEURL + api.search,
		headers:{
			sex:api.sex,
			source:api.source
		},
		data:{
			keyword:name,
			page:pageNum
		},
		success: function (res) {
			if(res && res.errno == 0 && res.rst){
				if(res.rst.data.length == 0){
					$(".loading").html("没有找到与“" + name + "”相关的商品");
					$(".loading").css({
						    'width': 'max-content',
    						'padding': "0 30px"
					})	
					return;
				}
				var html = '';
				maxPage = res.rst.pageInfo.maxPage;
				if(res.rst.data.length>0){
					if(meiriData.length != 0){
						meiriData = meiriData.concat(res.rst.data);
						html = template_home(meiriData)
					}else{
						meiriData = res.rst.data;
						html = template_home(meiriData)
					}
					$(".Recommend .commodity_list ul").html(html)
					loadingFlag = true;
					$(".loading").html("努力加载中...")
				}else{
					$(".loading").html("没有更多了")
				}
			}else{
				alert(res.err)
			}
			
		},
		fail: function (err) {
			console.log(err)
		}
	})
}
