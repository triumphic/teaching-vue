<template>
	<div id="helpCollage">
		<h3>已有1000人参与拼团</h3>
		<div class="userList">
			<ul>
				<li>
					<img src="https://img.alicdn.com/tfscom/i1/2944846611/TB1FDdGckSWBuNjSszdXXbeSpXa_!!0-item_pic.jpg_q60" />
					<p>创业真可爱 0元拿了【颈椎按摩器】治疗哈哈哈哈哈</p>
				</li>
				<li>
					<img src="https://img.alicdn.com/tfscom/i1/2944846611/TB1FDdGckSWBuNjSszdXXbeSpXa_!!0-item_pic.jpg_q60" />
					<p>创业真可爱 0元拿了【颈椎按摩器】治疗哈哈哈哈哈</p>
				</li>
				<li>
					<img src="https://img.alicdn.com/tfscom/i1/2944846611/TB1FDdGckSWBuNjSszdXXbeSpXa_!!0-item_pic.jpg_q60" />
					<p>创业真可爱 0元拿了【颈椎按摩器】治疗哈哈哈哈哈</p>
				</li>
				<li>
					<img src="https://img.alicdn.com/tfscom/i1/2944846611/TB1FDdGckSWBuNjSszdXXbeSpXa_!!0-item_pic.jpg_q60" />
					<p>创业真可爱 0元拿了【颈椎按摩器】治疗哈哈哈哈哈</p>
				</li>
				<li>
					<img src="https://img.alicdn.com/tfscom/i1/2944846611/TB1FDdGckSWBuNjSszdXXbeSpXa_!!0-item_pic.jpg_q60" />
					<p>创业真可爱 0元拿了【颈椎按摩器】治疗哈哈哈哈哈</p>
				</li>
				<li>
					<img src="https://img.alicdn.com/tfscom/i1/2944846611/TB1FDdGckSWBuNjSszdXXbeSpXa_!!0-item_pic.jpg_q60" />
					<p>创业真可爱 0元拿了【颈椎按摩器】治疗哈哈哈哈哈</p>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
</script>

<style scoped="scoped" lang="scss">
#helpCollage{
	width: 3.25rem;
	height: 1.825rem;
	background: rgba(255,208,46,0.17);
	border-radius: 0.1rem;
	h3{
		font-size: 0.14rem;
		color: #914E1E;
		line-height: 0.3rem;
		padding-left: 0.065rem;
		border-bottom:0.005rem solid #BFBFBF;
	}
	.userList{
		overflow: hidden;
	}
	ul{
		padding:0 0.07rem;
		height: 1.3rem;
		li{
			display:flex;
			justify-content: space-between;
			align-items: center;
			margin-top: 0.13rem;
			img{
				width: 0.35rem;
				height: 0.35rem;
				border-radius: 50%;
				margin-right: 0.13rem;
			}
			p{
				font-size: 0.14rem;
				color: #545454;
				overflow:hidden;
			    text-overflow:ellipsis;
			    white-space:nowrap
			}
		}
	}
}
</style>